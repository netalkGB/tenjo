---
name: e2e-punch
description: Minimal skill used by Playwright E2E to verify Punch slash force-load.
---

# E2E Punch Skill

When this skill is loaded, reply briefly with exactly: PUNCH_E2E_OK
